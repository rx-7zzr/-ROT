// script.js — small interactive touches
document.addEventListener('DOMContentLoaded', function(){
  // Simple ROT score generator for fun
  const btns = document.querySelectorAll('.btn.primary');
  btns.forEach(b => b.addEventListener('click', e => {
    e.preventDefault();
    const score = Math.floor(Math.random()*101);
    alert('Your ROT score: ' + score + '/100 — the higher, the more brainrot.');
  }));
});
