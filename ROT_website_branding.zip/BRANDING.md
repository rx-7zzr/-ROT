# ROT — Brainrot Token Branding Guide

## Logo
- Primary logo file: `rot-logo.png`
- Usage: Always leave clear space equal to the height of the 'R' around the logo.
- Do not stretch, rotate, or recolor the logo except to use the approved palette.

## Color Palette
- ROT Pink: #FF2D8A (primary brain color accent)
- Neon Green: #A7FF33 (token ticker and CTA)
- Deep Purple BG: #0F0326 (background)
- Accent Yellow: #FFD400 (logo outline)
- Off-White: #F6F5F7 (text on dark backgrounds)

## Typography
- Headline: 'Bebas Neue' or fallback 'Impact, Arial Black, sans-serif'
- Body: 'Inter' or fallback 'Helvetica, Arial, sans-serif'
- Use bold, high-contrast headings and monospace for code snippets.

## Voice & Copy Guidelines
- Tone: Absurd, self-aware, ironic, playful.
- Tagline: "Your brain is cooked. Your bags are too."
- Microcopy examples:
  - "Welcome to ROT — we celebrate brainrot culture and chaotic memes."
  - "Mint responsibly. HODL for the memes."
- Hashtags: #Brainrot #ROTcoin #ROTYourBag

## Iconography & Illustration Style
- Use neon, 80s-retro palette; bold outlines; slightly glitched or melting aesthetics.
- Mascot: melting anthropomorphic brain (see logo).

## Social Media Assets
- Avatar: square crop of `rot-logo.png`
- Banner size: 1500x500 with logo left and tagline right.

## File Contents
- rot-logo.png (primary logo)
- index.html, styles.css, script.js (website)
- README.md (this file)
